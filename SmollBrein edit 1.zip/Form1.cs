﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SmollBrein
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        public bool[] mainArray = new bool[25];

        private void SelectionButton_Click(object sender, EventArgs e)
        {
            //taking and cleaning input
            //!note that the order of the buttons are reversed after the first row, this is due to copy/pasting issues, 
            //however it will be compensated for in the cleanup stage

            //taking the first row
            
        }




        //forgive me lord, for i have sinned for not knowing how to do multiple onclick events

        private void button1_Click(object sender, EventArgs e)
        {
            if (mainArray[1] == false) 
            {
                mainArray[1] = true;
                button1.BackColor = Color.Black;
            }
            else if (mainArray[1] == true)
            {
                mainArray[1] = false;
                button1.BackColor = Color.Chartreuse;

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (mainArray[2] == false)
            {
                mainArray[2] = true;
                button2.BackColor = Color.Black;
            }
            else if (mainArray[2] == true)
            {
                mainArray[2] = false;
                button2.BackColor = Color.Chartreuse;

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (mainArray[3] == false)
            {
                mainArray[3] = true;
                button3.BackColor = Color.Black;
            }
            else if (mainArray[3] == true)
            {
                mainArray[3] = false;
                button3.BackColor = Color.Chartreuse;

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (mainArray[4] == false)
            {
                mainArray[4] = true;
                button4.BackColor = Color.Black;
            }
            else if (mainArray[4] == true)
            {
                mainArray[4] = false;
                button4.BackColor = Color.Chartreuse;

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (mainArray[5] == false)
            {
                mainArray[5] = true;
                button5.BackColor = Color.Black;
            }
            else if (mainArray[5] == true)
            {
                mainArray[5] = false;
                button5.BackColor = Color.Chartreuse;

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (mainArray[6] == false)
            {
                mainArray[6] = true;
                button6.BackColor = Color.Black;
            }
            else if (mainArray[6] == true)
            {
                mainArray[6] = false;
                button6.BackColor = Color.Chartreuse;

            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (mainArray[7] == false)
            {
                mainArray[7] = true;
                button7.BackColor = Color.Black;
            }
            else if (mainArray[7] == true)
            {
                mainArray[7] = false;
                button7.BackColor = Color.Chartreuse;

            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (mainArray[8] == false)
            {
                mainArray[8] = true;
                button8.BackColor = Color.Black;
            }
            else if (mainArray[8] == true)
            {
                mainArray[8] = false;
                button8.BackColor = Color.Chartreuse;

            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (mainArray[9] == false)
            {
                mainArray[9] = true;
                button9.BackColor = Color.Black;
            }
            else if (mainArray[9] == true)
            {
                mainArray[9] = false;
                button9.BackColor = Color.Chartreuse;

            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (mainArray[10] == false)
            {
                mainArray[10] = true;
                button10.BackColor = Color.Black;
            }
            else if (mainArray[10] == true)
            {
                mainArray[10] = false;
                button10.BackColor = Color.Chartreuse;

            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (mainArray[11] == false)
            {
                mainArray[11] = true;
                button11.BackColor = Color.Black;
            }
            else if (mainArray[11] == true)
            {
                mainArray[11] = false;
                button11.BackColor = Color.Chartreuse;

            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (mainArray[12] == false)
            {
                mainArray[12] = true;
                button12.BackColor = Color.Black;
            }
            else if (mainArray[12] == true)
            {
                mainArray[12] = false;
                button12.BackColor = Color.Chartreuse;

            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (mainArray[13] == false)
            {
                mainArray[13] = true;
                button13.BackColor = Color.Black;
            }
            else if (mainArray[13] == true)
            {
                mainArray[13] = false;
                button13.BackColor = Color.Chartreuse;

            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (mainArray[14] == false)
            {
                mainArray[14] = true;
                button14.BackColor = Color.Black;
            }
            else if (mainArray[14] == true)
            {
                mainArray[14] = false;
                button14.BackColor = Color.Chartreuse;

            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (mainArray[15] == false)
            {
                mainArray[15] = true;
                button15.BackColor = Color.Black;
            }
            else if (mainArray[15] == true)
            {
                mainArray[15] = false;
                button15.BackColor = Color.Chartreuse;

            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (mainArray[16] == false)
            {
                mainArray[16] = true;
                button16.BackColor = Color.Black;
            }
            else if (mainArray[16] == true)
            {
                mainArray[16] = false;
                button16.BackColor = Color.Chartreuse;

            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (mainArray[17] == false)
            {
                mainArray[17] = true;
                button17.BackColor = Color.Black;
            }
            else if (mainArray[17] == true)
            {
                mainArray[17] = false;
                button17.BackColor = Color.Chartreuse;

            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (mainArray[18] == false)
            {
                mainArray[18] = true;
                button18.BackColor = Color.Black;
            }
            else if (mainArray[18] == true)
            {
                mainArray[18] = false;
                button18.BackColor = Color.Chartreuse;

            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (mainArray[19] == false)
            {
                mainArray[19] = true;
                button19.BackColor = Color.Black;
            }
            else if (mainArray[19] == true)
            {
                mainArray[19] = false;
                button19.BackColor = Color.Chartreuse;

            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (mainArray[20] == false)
            {
                mainArray[20] = true;
                button20.BackColor = Color.Black;
            }
            else if (mainArray[20] == true)
            {
                mainArray[20] = false;
                button20.BackColor = Color.Chartreuse;

            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            if (mainArray[21] == false)
            {
                mainArray[21] = true;
                button21.BackColor = Color.Black;
            }
            else if (mainArray[21] == true)
            {
                mainArray[21] = false;
                button21.BackColor = Color.Chartreuse;

            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            if (mainArray[22] == false)
            {
                mainArray[22] = true;
                button22.BackColor = Color.Black;
            }
            else if (mainArray[22] == true)
            {
                mainArray[22] = false;
                button22.BackColor = Color.Chartreuse;

            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            if (mainArray[23] == false)
            {
                mainArray[23] = true;
                button23.BackColor = Color.Black;
            }
            else if (mainArray[23] == true)
            {
                mainArray[23] = false;
                button23.BackColor = Color.Chartreuse;

            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            if (mainArray[24] == false)
            {
                mainArray[24] = true;
                button24.BackColor = Color.Black;
            }
            else if (mainArray[24] == true)
            {
                mainArray[24] = false;
                button24.BackColor = Color.Chartreuse;

            }
        }

        private void button25_Click(object sender, EventArgs e)
        {
            if (mainArray[25] == false)
            {
                mainArray[25] = true;
                button25.BackColor = Color.Black;
            }
            else if (mainArray[25] == true)
            {
                mainArray[25] = false;
                button25.BackColor = Color.Chartreuse;

            }
        }
    }
}
